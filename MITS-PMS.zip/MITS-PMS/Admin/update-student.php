<?php  
	session_start();
	if (!$_SESSION["LoginAdmin"])
	{
		echo '<script> alert("Your Are Not Authorize Person For This link");</script>';
        echo '<script>window.location="../login/login.php"</script>';
	}
		require_once "../connection/connection.php";
		$_SESSION["LoginStudent"]="";
	?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Student</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" 
    rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

</head>
<style>
    input{
        margin-bottom: 15px;
    }
</style>
<?php
    
    $Stud_ID = $_REQUEST['Stud_ID'];

    $query = "SELECT * FROM `student` WHERE `Stud_ID` = '$Stud_ID'";
   
    $run = mysqli_query($con, $query);
    
    $row = mysqli_fetch_array($run);
    
    $file1 = $row['Stud_Image'];
    $file2 = $row['Mark_List_10th']; 
    $file3 = $row['Mark_List_12th'];
    
 ?>
<body>
    <div class="col-xl-12 col-lg-12 col-md-12 w-100">
		<div class="bg-secondary text-center">
			<div class="table-one flex-wrap flex-md-no-wrap pt-3 pb-2 mb-3 text-white admin-dashboard pl-3">
				<h4>Student Updation Form</h4>
			</div>
		</div>
	</div>
    <div class="container mt-5 mb-5">        
        <form enctype="multipart/form-data" method="POST">
            <h5>Personal Details</h5>
            <div class="row">           
                <div class="col">
                    <label>Name</label>
                    <input type="text" class="form-control" value= "<?php echo $row['Stud_Name']; ?>" name="Stud_Name">
                </div>
                <div class="col">
                    <label>Date of Birth</label>
                    <input type="text" class="form-control" value = "<?php echo $row['Stud_DOB'] ?>" name="Stud_DOB">
                </div>
                <div class="col">
                    <label>Gender</label>
                    <input type="text" class="form-control" value = "<?php echo $row['Stud_Gender'] ?>" name="Stud_Gender">
                </div>
            </div>
            <div class="row"> 
                <div class="col">
                    <label>Mobile No</label>
                    <input type="text" class="form-control" value= "<?php echo $row['Stud_Mob']; ?>" name="Stud_Mob">
                </div>
                <div class="col">
                    <label>Email</label>
                    <input type="email" class="form-control" value= "<?php echo $row['Stud_Email']; ?>" name="Stud_Email">
                </div>                       
                <div class="col">
                    <label>Address</label>
                    <input type="text" class="form-control" value= "<?php echo $row['Stud_Address']; ?>" name="Stud_Address">
                </div>
            </div>
            <div class="row">
                <div class="col">
                    <label>Caste/Religion</label>
                    <input type="text" class="form-control" value= "<?php echo $row['Stud_Caste']; ?>" name="Stud_Caste">
                </div>
                <div class="col">
                    <label>Mother Tongue</label>
                    <input type="text" class="form-control" value= "<?php echo $row['Stud_M_T']; ?>" name="Stud_M_T">
                </div>            
                <div class="col">
                    <label>Course</label>
                    <input type="text" class="form-control" value= "<?php echo $row['Stud_Course']; ?>" name="Stud_Course">
                </div>                     
            </div>
            <div class="row">   
                <div class="col">
                    <label>Batch</label>
                    <input type="text" class="form-control" value= "<?php echo $row['Stud_Batch']; ?>" name="Stud_Batch">
                </div> 
                <div class="col">
                    <label>Semester</label>
                    <input type="text" class="form-control" value= "<?php echo $row['Stud_Sem']; ?>" name="Stud_Sem">
                </div>
                <div class="col">
                    <label>Student ID Proof No</label>
                    <input type="text" class="form-control" value= "<?php echo $row['Stud_ID_No']; ?>" name="Stud_ID_No">
                </div>
            </div>
            <div class="row"> 
                <div class="col-sm-4">
                    <label>University Reg No</label>
                    <input type="text" class="form-control" value= "<?php echo $row['Stud_Reg_No']; ?>" name="Stud_Reg_No">
                </div>  
                <div class="col-sm-4">
                    <label>Student Image</label>
                    <input type="file" class="form-control" value= "<?php echo $row['Stud_Image']; ?>" name="Stud_Image">
                </div> 
            </div>
            <h5>Parental Information</h5>
            <div class="row">
                <div class="col">
                    <label>Father's Name</label>
                    <input type="text" class="form-control" value= "<?php echo $row['Stud_Father_Name']; ?>" name="Stud_Father_Name">
                </div>
                <div class="col">
                    <label>Father's Occupation</label>
                    <input type="text" class="form-control" value= "<?php echo $row['Stud_Father_Occ']; ?>" name="Stud_Father_Occ">
                </div>
                <div class="col">
                    <label>Father's Mobile No</label>
                    <input type="text" class="form-control" value= "<?php echo $row['Stud_Father_No']; ?>" name="Stud_Father_No">
                </div>
            </div>            
            <div class="row">
                <div class="col">
                    <label>Mother's Name</label>
                    <input type="text" class="form-control" value= "<?php echo $row['Stud_Mother_Name']; ?>" name="Stud_Mother_Name">
                </div>
                <div class="col">
                    <label>Mother's Occupation</label>
                    <input type="text" class="form-control" value= "<?php echo $row['Stud_Mother_Occ']; ?>" name="Stud_Mother_Occ">
                </div>
                <div class="col">
                    <label>Mother's Mobile No</label>
                    <input type="text" class="form-control" value= "<?php echo $row['Stud_Mother_No']; ?>" name="Stud_Mother_No">
                </div>
            </div>
            <div class="row">
                <div class="col-sm-4">
                    <label>Guardian Email</label>
                    <input type="text" class="form-control" value= "<?php echo $row['Guardian_Email']; ?>" name="Guardian_Email">
                </div>
                <div class="col-sm-4">
                    <label>Annual Income</label>
                    <input type="text" class="form-control" value= "<?php echo $row['Annual_Income']; ?>" name="Annual_Income">
                </div>
            </div>
            <h5>Academic Information</h5>
            <div class="row">
                <div class="col">
                    <label>12th Board</label>
                    <input type="text" class="form-control" value= "<?php echo $row['Board_12th']; ?>" name="Board_12th">
                </div>
                <div class="col">
                    <label>12th School</label>
                    <input type="text" class="form-control" value= "<?php echo $row['School_12th']; ?>" name="School_12th">
                </div>
                <div class="col">
                    <label>Stream</label>
                    <input type="text" class="form-control" value= "<?php echo $row['Stream_12th']; ?>" name="Stream_12th">
                </div>
            </div>
            <div class="row">
                <div class="col">
                    <label>Year of Passing</label>
                    <input type="text" class="form-control" value= "<?php echo $row['YOP_12th']; ?>" name="YOP_12th">
                </div>
                <div class="col">
                    <label>10th Board</label>
                    <input type="text" class="form-control" value= "<?php echo $row['Board_10th']; ?>" name="Board_10th">
                </div>
                <div class="col">
                    <label>10th School</label>
                    <input type="text" class="form-control" value= "<?php echo $row['School_10th']; ?>" name="School_10th">
                </div>
            </div>
            <div class="row">
                <div class="col">
                    <label>Year of Passing</label>
                    <input type="text" class="form-control" value= "<?php echo $row['YOP_10th']; ?>" name="YOP_10th">
                </div>
                <div class="col">
                    <label>CGPA</label>
                    <input type="text" class="form-control" value= "<?php echo $row['CGPA']; ?>" name="CGPA">
                </div>
                <div class="col">
                    <label>10th Marklist</label>
                    <input type="file" class="form-control" value= "<?php echo $row['Mark_List_10th']; ?>" name="Mark_List_10th">
                </div>
            </div>
            <div class="row">
                <div class="col-sm-4">
                    <label>12th Marklist</label>
                    <input type="file" class="form-control" value= "<?php echo $row['Mark_List_12th']; ?>" name="Mark_List_12th">
                </div> 
            </div>
            <div class="footer mt-3 text-center">
                <input type="Submit" class="btn btn-success" value="Update" name = "update">
                <input type="Button" class="btn btn-danger" value="Back" onClick="history.back()">
            </div>
        </form>
    </div>

</body>
</html>
<?php
if(isset($_POST['update'])){
   
    $Stud_Name =$_POST['Stud_Name'];

		$Stud_DOB =$_POST['Stud_DOB'];

		$Stud_Gender =$_POST['Stud_Gender'];

		$Stud_Mob =$_POST['Stud_Mob'];

		$Stud_Email =$_POST['Stud_Email'];

		$Stud_Address =$_POST['Stud_Address'];

		$Stud_Caste =$_POST['Stud_Caste'];

		$Stud_M_T =$_POST['Stud_M_T'];

		$Stud_Course =$_POST['Stud_Course'];

		$Stud_Batch =$_POST['Stud_Batch'];

		$Stud_Sem =$_POST['Stud_Sem'];

		$Stud_ID_No =$_POST['Stud_ID_No'];

		$Stud_Reg_No =$_POST['Stud_Reg_No'];

		$Stud_Father_Name =$_POST['Stud_Father_Name'];

		$Stud_Father_Occ =$_POST['Stud_Father_Occ'];

		$Stud_Father_No =$_POST['Stud_Father_No'];

		$Stud_Mother_Name =$_POST['Stud_Mother_Name'];

		$Stud_Mother_Occ =$_POST['Stud_Mother_Occ'];

		$Stud_Mother_No =$_POST['Stud_Mother_No'];

		$Guardian_Email =$_POST['Guardian_Email'];

		$Annual_Income =$_POST['Annual_Income'];

		$Board_12th =$_POST['Board_12th'];

		$School_12th =$_POST['School_12th'];

		$Stream_12th =$_POST['Stream_12th'];

		$YOP_12th =$_POST['YOP_12th'];

		$Board_10th =$_POST['Board_10th'];

		$School_10th =$_POST['School_10th'];

		$YOP_10th =$_POST['YOP_10th'];

		$CGPA =$_POST['CGPA'];

    if(!file_exists($_FILES['Stud_Image']['tmp_name']) || !is_uploaded_file($_FILES['Stud_Image']['tmp_name'])) 
    {
        $Stud_Image = $file1;        
    }
    else
    {       
        $Stud_Image = $_FILES['Stud_Image']['name'];
        $tmp_name=$_FILES['Stud_Image']['tmp_name'];
        $path1 = "images/".$Stud_Image;
        move_uploaded_file($tmp_name, $path1);
    }
    
    if(!file_exists($_FILES['Mark_List_10th']['tmp_name']) || !is_uploaded_file($_FILES['Mark_List_10th']['tmp_name'])) 
    {
        $Mark_List_10th = $file2;        
    }
    else
    {       
        $Mark_List_10th = $_FILES['Mark_List_10th']['name'];
        $tmp_name=$_FILES['Mark_List_10th']['tmp_name'];
        $path2 = "images/".$Mark_List_10th;
        move_uploaded_file($tmp_name, $path2);
    }   

    
    if(!file_exists($_FILES['Mark_List_12th']['tmp_name']) || !is_uploaded_file($_FILES['Mark_List_12th']['tmp_name'])) 
    {
        $Mark_List_12th = $file3;        
    }
    else
    {       
        $Mark_List_12th = $_FILES['Mark_List_12th']['name'];
        $tmp_name=$_FILES['Mark_List_12th']['tmp_name'];
        $path3 = "images/".$Mark_List_12th;
        move_uploaded_file($tmp_name, $path3);
    }   

    $upquery = "UPDATE `student` SET `Stud_Name`='$Stud_Name',`Stud_DOB`='$Stud_DOB',`Stud_Gender`='$Stud_Gender', `Stud_Mob`='$Stud_Mob',`Stud_Email`='$Stud_Email',`Stud_Address`='$Stud_Address',`Stud_Caste`='$Stud_Caste',`Stud_M_T`='$Stud_M_T',`Stud_Course`='$Stud_Course',`Stud_Batch`='$Stud_Batch',`Stud_Sem`='$Stud_Sem',`Stud_ID_No`='$Stud_ID_No',`Stud_Reg_No`='$Stud_Reg_No',`Stud_Father_Name`='$Stud_Father_Name',`Stud_Father_Occ`='$Stud_Father_Occ',`Stud_Father_No`='$Stud_Father_No',`Stud_Mother_Name`='$Stud_Mother_Name',`Stud_Mother_Occ`='$Stud_Mother_Occ',`Stud_Mother_No`='$Stud_Mother_No',`Guardian_Email`='$Guardian_Email',`Annual_Income`='$Annual_Income',`Board_12th`='$Board_12th',`School_12th`='$School_12th',`Stream_12th`='$Stream_12th',`YOP_12th`='$YOP_12th',`Board_10th`='$Board_10th',`School_10th`='$School_10th',`YOP_10th`='$YOP_10th',`CGPA`='$CGPA',`Stud_Image`='$Stud_Image',`Mark_List_10th`='$Mark_List_10th',`Mark_List_12th`='$Mark_List_12th' WHERE `Stud_ID`='$Stud_ID'";

    $run1=mysqli_query($con,$upquery);

    if ($run1) {
        echo "<script>confirm('Record updated'); window.location='Student.php';</script>";
    }
    else {
        echo "<script>alert('Record not updated'); window.location='Student.php';</script>";
    }
}
?>