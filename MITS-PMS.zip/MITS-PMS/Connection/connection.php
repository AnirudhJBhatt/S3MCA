<?php 
	$con=mysqli_connect("localhost:3306","root","","mits_pms");
	if(!$con)
	{
		echo "Connection is not Successfully";
	}
?>