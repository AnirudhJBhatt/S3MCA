<!---------------- Session starts form here ----------------------->
<?php  
	session_start();
	if (!$_SESSION["LoginStudent"])
	{
		echo '<script> alert("Your Are Not Authorize Person For This link");</script>';
        echo '<script>window.location="../login/login.php"</script>';
	}
		require_once "../connection/connection.php";
		$_SESSION['LoginTeacher']="";
		
		$Stud_ID=$_SESSION['LoginStudent'];
	?>
<!---------------- Session Ends form here ------------------------>
<?php
    $J_ID=$_GET['J_ID'];
    $C_ID=$_GET['C_ID'];
    $query="INSERT INTO `application`(`Stud_ID`, `J_ID`, `C_ID`, `App_Status`) VALUES ('$Stud_ID','$J_ID','$C_ID','Pending')";
    $run=mysqli_query($con,$query);
    if($run){
		header('Location: student-circular.php');
    }
    
?>