
	<?php include('common/header.php') ?>
	<div>
		<img src="Images/imperial-banner-1.png" alt="college background" class="responsive" width="100%" height="450">
	</div>
	
		<div class="paragraph">
			<p>
			Muthoot Institute of Technology and Science (MITS) is promoted by Muthoot M. George Institute of Technology, a Section 25 Company within the Muthoot Group. MITS is a self financing technical institution offering postgraduate and undergraduate engineering programmes, situated in the industrial suburb of Kochi, close to the Smart City and Info Park, approximately 15 kms from Vytilla Junction towards Muvattupuzha on the Cochin Madurai National Highway.
			</p>
		</div>
	<?php include('common/footer.php') ?>
</body>
</html>

